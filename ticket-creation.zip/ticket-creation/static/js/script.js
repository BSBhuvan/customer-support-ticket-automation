// static/js/script.js

document.addEventListener('DOMContentLoaded', () => {
    const ticketItems = document.querySelectorAll('.ticket-item');

    ticketItems.forEach(item => {
        item.addEventListener('click', () => {
            alert(`You clicked on ticket: ${item.querySelector('h3').textContent}`);
        });
    });
});
