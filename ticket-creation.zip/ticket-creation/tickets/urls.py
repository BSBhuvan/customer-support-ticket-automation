from django.urls import path
from . import views

urlpatterns = [
    path('', views.ticket_list, name='ticket-list'),
    path('create/', views.ticket_create, name='ticket-create'),
    path('assign/<int:ticket_id>/', views.assign_ticket, name='ticket-assign'),
    path('history/<int:ticket_id>/', views.ticket_history, name='ticket-history'),
]
