from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import Ticket, TicketAssignment, TicketStatusHistory
from .forms import TicketForm
from django.core.mail import send_mail
from django.conf import settings
from django.contrib import messages

# Display list of tickets
def ticket_list(request):
    tickets = Ticket.objects.all()
    return render(request, 'tickets/ticket_list.html', {'tickets': tickets})

# Show form to create a new ticket
def ticket_create(request):
    if request.method == 'POST':
        form = TicketForm(request.POST)
        if form.is_valid():
            # Save ticket
            ticket = form.save()

            # If the ticket's priority is critical, send an email notification
            if ticket.priority == 'critical':
                send_mail(
                    f"Critical Ticket Created: {ticket.title}",
                    f"Ticket Details:\n\nTitle: {ticket.title}\nDescription: {ticket.description}\nPriority: {ticket.priority}",
                    settings.EMAIL_HOST_USER,
                    ['admin@example.com'],  # Add recipient email
                )

            messages.success(request, 'Ticket created successfully!')
            return redirect('ticket-list')  # Redirect to the ticket list page
    else:
        form = TicketForm()
    
    return render(request, 'tickets/ticket_create.html', {'form': form})

# Assign a ticket to a user
def assign_ticket(request, ticket_id):
    ticket = Ticket.objects.get(pk=ticket_id)
    
    if request.method == 'POST':
        assigned_to = request.POST['assigned_to']
        ticket_assignment = TicketAssignment.objects.create(
            ticket=ticket,
            assigned_to=assigned_to
        )
        ticket_assignment.save()

        messages.success(request, f"Ticket '{ticket.title}' assigned to {assigned_to}")
        return redirect('ticket-list')  # Redirect to the ticket list after assignment
    else:
        return render(request, 'tickets/ticket_assign.html', {'ticket': ticket})

# Display the history of a ticket (status changes)
def ticket_history(request, ticket_id):
    ticket = Ticket.objects.get(pk=ticket_id)
    history = TicketStatusHistory.objects.filter(ticket=ticket).order_by('-changed_at')
    return render(request, 'tickets/ticket_history.html', {'ticket': ticket, 'history': history})
