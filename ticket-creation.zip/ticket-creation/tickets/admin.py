from django.contrib import admin
from .models import Ticket, TicketAssignment, TicketStatusHistory

# Register the models
admin.site.register(Ticket)
admin.site.register(TicketAssignment)
admin.site.register(TicketStatusHistory)
