from rest_framework import serializers
from .models import Ticket, TicketAssignment

class TicketSerializer(serializers.ModelSerializer):
    class Meta:
        model = Ticket
        fields = ['id', 'title', 'description', 'status', 'priority', 'created_at', 'updated_at']

class TicketAssignmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = TicketAssignment
        fields = ['ticket', 'assigned_to', 'assigned_at']
