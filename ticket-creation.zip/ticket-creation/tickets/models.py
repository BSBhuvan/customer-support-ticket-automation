from django.db import models
from django.core.mail import send_mail
from django.conf import settings


class Ticket(models.Model):
    STATUS_CHOICES = [
        ('open', 'Open'),
        ('in_progress', 'In Progress'),
        ('resolved', 'Resolved'),
        ('closed', 'Closed'),
    ]

    PRIORITY_CHOICES = [
        ('low', 'Low'),
        ('medium', 'Medium'),
        ('high', 'High'),
        ('critical', 'Critical'),
    ]

    title = models.CharField(max_length=255)
    description = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='open')
    priority = models.CharField(max_length=10, choices=PRIORITY_CHOICES, default='medium')

    def save(self, *args, **kwargs):
        if self.pk:  # If the ticket is being updated
            previous = Ticket.objects.get(pk=self.pk)
            if previous.status != self.status:
                TicketStatusHistory.objects.create(ticket=self, status=self.status)

        super().save(*args, **kwargs)

        # Send notification for critical priority tickets
        if self.priority == 'critical':
            send_mail(
                f"Critical Ticket Created/Updated: {self.title}",
                f"Ticket Details:\n\nTitle: {self.title}\nDescription: {self.description}\nStatus: {self.status}",
                settings.EMAIL_HOST_USER,
                ['admin@example.com'],  # Add the email of the person or group to notify
            )

    def __str__(self):
        return self.title


class TicketAssignment(models.Model):
    ticket = models.ForeignKey(Ticket, on_delete=models.CASCADE)
    assigned_to = models.CharField(max_length=255)  # Link to User model if needed
    assigned_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.ticket.title} assigned to {self.assigned_to}"


class TicketStatusHistory(models.Model):
    ticket = models.ForeignKey(Ticket, on_delete=models.CASCADE)
    status = models.CharField(max_length=20, choices=Ticket.STATUS_CHOICES)
    changed_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.ticket.title} changed to {self.status} on {self.changed_at}"
